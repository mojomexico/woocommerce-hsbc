<?php
/* Description: Pasarela Banco HSBC
Version: 0.1 Payworks2 3D
Author: MOJOMEXICO (https://mojomexico.com.mx)
*/

class WC_HSBC_Mojomexico extends WC_Payment_Gateway {  

        
		public function __construct(){
			global $woocommerce;
                        
                        
		$this->id 		        = 'hsbc_mojomexico';
    		$this->icon 		        = apply_filters('woocommerce_hsbc_mojomexico', plugins_url( 'hsbc.jpg' , __FILE__ ) );            
        	$this->method_title     	= __( 'HSBC PROSA MEXICO', 'woocommerce_hsbc_mojomexico' );
        	$this->method_description  	= 'Pasarela de Pago HSBC Mexico para tiendas Woocommerce creado por Mojomexico.company';

                         
			$this->init_form_fields();
			
			$this->init_settings();


			                        
                        if ( 'yes' == $this->debug ){
				if(version_compare( WOOCOMMERCE_VERSION, '2.1', '>=')){
					$this->log = new WC_Logger();
				}else{
					$this->log = $woocommerce->logger();
				}
			}
	
		}

        
        public function admin_options(){
            
            
            echo '<h3>Tarjetas HSBC  3D Security </h3>';
            echo '<br /> <p><img src="https://mojomexico.com.mx/img/caja-hsbc1.jpg" width="200">Plugin Woocommerce para conectar Banco HSBC /  tarjetas VISA y Mastercard, una solución más creado por <a href="https://mojomexico.com.mx" target="_blank">Mojomexico.com.mx</a></p> Esta version requiere configuraciones especiales dependiendo del MODELO DE SEGURIDAD que el banco le asigne a cada Cliente, es necesario gestionar ante el banco directo tus llaves TPVI para ligar tu Cuenta Bancaria con tu tienda Woocommerce, pide este y otros productos en nuestra tienda web.</p><a href="https://www.youtube.com/user/mojomexico" target="_blank">VER VIDEO DE ESTE CONECTOR FUNCIONANDO EN YOUTUBE-CANAL-MOJOMEXICO</a>';
            
            }
        
function add_log( $message ) {
        if ( $this->debug=='yes' ) {
            if ( empty( $this->log ) )
                $this->log = new WC_Logger();
            $this->log->add( 'hsbc_mojomexico', $message );
        }
    }

	    
		function init_form_fields(){
			$this->form_fields = array(
			'enabled' => array(
							'title' 			=> 	'Activado/Apagado',
							'type' 				=> 	'checkbox',
							'label' 			=>	'Default Modulo Activado',
							'description' 		=> 	'Mostrar ó esconder pasarela.',
                    		'desc_tip'      	=> 	true,
							'default' 			=> 	'yes'
						),
				 'title' => array(
								'title' 		=> 	'Title',
								'type' 			=> 	'text',
								'description' 	=> 	'Aqui el texto que se mostrará en la opcion de pago.',
                    			'desc_tip'      => 	false,
								'default' 		=>  'Tarjetas de credito y debito HSBC '
							),
				'description' => array(
								'title' 		=> 	'Descripción',
								'type' 			=> 	'textarea',
								'description' 	=> 	'Mensaje de instrucciones.',
								'default' 		=> 	'Pago con tarjetas VISA y Mastercard Nacionales e Internacionales.'
							)
                                     
			);
	}

		function generate_hsbc_form( $order ) {
                echo '<h3>PARA ACTIVAR ESTE CONECTOR ES NECESARIO PEDIR LA VERSION FINAL EN LA TIENDA WEB DE NUESTRA MARCA</h3>';
                }

		function process_payment( $order_id ) {
                         global $woocommerce;
			$order = new WC_Order( $order_id );
                
               return array(
				'result' 	=> 'success',
				'redirect'	=>  $order->get_checkout_payment_url( true ));
		}


	    
		function receipt_page( $order ) {
			
			echo $this->generate_hsbc_form( $order );
                        
		}

}

function woocommerce_add_hsbc_mojomexico($methods) {
		$methods[] = 'WC_HSBC_Mojomexico';
		return $methods;
	}

	add_filter('woocommerce_payment_gateways', 'woocommerce_add_hsbc_mojomexico' );
